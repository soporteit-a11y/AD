import React, { useMemo, useState } from "react";

// Datos de ejemplo
const CATEGORIES = ["Biografía", "Premios", "Cultura pop"];
const ARTICLES = [
  {
    id: "bio",
    title: "Biografía completa de Abella Danger",
    category: "Biografía",
    date: "2025-01-15",
    readTime: 7,
    summary: "Una panorámica no explícita sobre sus orígenes y evolución.",
    content: [
      "Abella Danger nació en Miami, Florida (EE. UU.).",
      "Comenzó su carrera a mediados de la década de 2010.",
      "Se ha convertido en una figura reconocida en la cultura pop."
    ],
  },
];

export default function AbellaDangerMagazine() {
  const [query, setQuery] = useState("");
  const [activeCat, setActiveCat] = useState("Todos");

  const categories = useMemo(() => ["Todos", ...CATEGORIES], []);

  const filtered = useMemo(() => {
    return ARTICLES.filter((a) => {
      const q = query.toLowerCase();
      const matchesQuery =
        !q ||
        a.title.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q);
      const matchesCat = activeCat === "Todos" || a.category === activeCat;
      return matchesQuery && matchesCat;
    });
  }, [query, activeCat]);

  return (
    <div className="min-h-screen text-white p-6">
      <h1 className="text-4xl font-bold">Abella Danger Magazine</h1>
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Buscar artículos..."
        className="w-full max-w-md mb-6 p-2 rounded bg-slate-800 text-white"
      />
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((a) => (
          <div key={a.id} className="p-4 rounded bg-slate-700 shadow">
            <h2 className="text-xl font-semibold">{a.title}</h2>
            <p className="text-sm text-slate-300">{a.summary}</p>
          </div>
        ))}
      </div>
    </div>
  );
}